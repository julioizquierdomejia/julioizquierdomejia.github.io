# Contributing guide

## Contributing code

Setting up a dev environmetn is easy. All you need is Node.js. See: http://docpress.github.io/advanced/hacking.html
